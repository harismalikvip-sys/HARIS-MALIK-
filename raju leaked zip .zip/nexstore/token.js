module.exports = {
  BOT_TOKEN: '9280365252:AAEPzEyux8JPWL5zY9dl10p3Mi71440sBpQ',  
  startupPassword: '1'
};